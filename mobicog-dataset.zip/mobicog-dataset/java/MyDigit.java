package edu.virginia.cs.minicog;

import java.util.ArrayList;

public class MyDigit  implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8725164052406229028L;
	public MyPoint loc;
	public int ID;
	public ArrayList<MyStroke> s;
	
	public MyDigit() {
		loc = new MyPoint();
		s = new ArrayList<MyStroke>();
		s.clear();
	}
}
