1. To read raw data files (e.g. 1.mc) use ObjectInputStream:
-----------------------------------------------------------

File infile = new File("1.mc");
ObjectInputStream inp = new ObjectInputStream(new FileInputStream(infile));

MyDigit tdigit = new MyDigit();
for(int i = 0; i < 12; i++) {
	tdigit = (MyDigit) inp.readObject();
	//Now you have the digit object;
	//Each MyDigit contains an array list of MyStroke;
	//Each MyStroke contains an array list of MyPoint;
}	

2. Each *.mc.txt is an already computed feature file.