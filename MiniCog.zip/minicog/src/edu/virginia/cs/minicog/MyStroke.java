package edu.virginia.cs.minicog;

import java.util.ArrayList;

public class MyStroke  implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3068303439632728502L;
	public ArrayList<MyPoint> p;
	public MyPoint v;
	public float leftX, rightX;
	
	public MyStroke() {
		p = new ArrayList<MyPoint>();
		p.clear();
		v = new MyPoint();
		leftX = 1;
		rightX = -1;
	}
	
	public void updateCOG() 
	{
		float sx = 0, sy = 0;
		
		int lim = p.size();
		
		for(int i = 0; i < lim; i++) {
			sx = sx + p.get(i).X;
			sy = sy + p.get(i).Y;
		}
		
		if(lim > 0){
			v.X = sx / lim;
			v.Y = sy / lim;
		}
	}
	
	public void normalizePoints() 
	{
		int i, lim = p.size();
		float tx, ty;
		float minX = Float.MAX_VALUE, maxX = Float.MIN_VALUE, minY = Float.MAX_VALUE, maxY = Float.MIN_VALUE;
		float rx, ry, scl;
		
		for(i = 0; i < lim; i++) {
			
			tx = p.get(i).X;
			ty = p.get(i).Y;
			
			minX = Math.min(minX, tx);
			maxX = Math.max(maxX, tx);
			minY = Math.min(minY, ty);
			maxY = Math.max(maxY, ty);
			
			tx = tx - v.X;
			ty = ty - v.Y;
			
			MyPoint tp = new MyPoint(tx, ty);
			p.set(i, tp);
		}
		
		leftX = minX;
		rightX = maxX;
		
		rx = maxX - minX;
		ry = maxY - minY;
		
		if(rx > ry) scl = 200f / rx;
		else scl = 200f / ry;
			
		for(i = 0; i < lim; i++) {
			tx = p.get(i).X * scl;
			ty = p.get(i).Y * scl;
			
			MyPoint tp = new MyPoint(tx, ty);
			p.set(i, tp);
		}
		
	}
	
}
