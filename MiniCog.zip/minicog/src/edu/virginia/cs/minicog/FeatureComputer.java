package edu.virginia.cs.minicog;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.StringTokenizer;

import android.util.Log;

public class FeatureComputer {

	float A = 2.4142f, B = 0.4142f;
	
	public float[][][] tset; //12 digits x total files x 8 features
	public int totalFiles = 0;
	public static int FDIM = 19; //chaincode2, chaincode3, 2part
	public static float FMAX = Float.MAX_VALUE/500;
	
	private ArrayList<MyTouple> dvals = new ArrayList<MyTouple>();
	
	public FeatureComputer() {
		tset = null;
		totalFiles = 0;
		dvals.clear();
	}
	
	public int getTurnDirection(MyPoint p1, MyPoint p2)
	{
		float dx, dy;
		dx = p2.X - p1.X;
		dy = p2.Y - p1.Y;
		int ret = 0;
		
		if(dx >= 0){
			if(dy >= 0){
				if(dy > A * dx) ret = 2;
				else if(dy < B*dx) ret = 0;
				else ret = 1;
			}
			else{
				dy = -dy;
				if(dy > A * dx) ret = 5;
				else if(dy < B*dx) ret = 0;
				else ret = 4;
			}
		}
		else{
			dx = -dx;
			if(dy >= 0){
				if(dy > A * dx) ret = 2;
				else if(dy < B*dx) ret = 7;
				else ret = 3;
			}
			else{
				dy = -dy;
				if(dy > A * dx) ret = 5;
				else if(dy < B*dx) ret = 7;
				else ret = 6;
			}
		}
		return ret;
	}
	
	public float[] getFetures(MyDigit d) 
	{
		float[] f = new float[FDIM];
		Log.v("Feature Computer Activity", "computing features ....");
		
		int i = 0;
		for(i = 0; i < FDIM; i++){
			f[i] = 0;
		}
		
		int nums = d.s.size();
		int pcount = 0;
		
		if(nums > 0){
			
			for(int si = 0; si < nums; si++) {
				
				MyStroke tstr = d.s.get(si);
				int nump = tstr.p.size();
				
				if(nump >= 2){
					for(int pi = 0; pi < nump-1; pi++) {
						MyPoint p1 = tstr.p.get(pi);
						MyPoint p2 = tstr.p.get(pi+1);
						int cc = getTurnDirection(p1, p2);
						f[cc] = f[cc] + 1;
						//f[7-cc] = f[7-cc] + 1;
						pcount += 1;
					}
				}
				
				if(nump >= 3){
					for(int pi = 0; pi < nump-2; pi++) {
						MyPoint p1 = tstr.p.get(pi);
						MyPoint p2 = tstr.p.get(pi+2);
						int cc = getTurnDirection(p1, p2);
						f[cc+8] = f[cc+8] + 1;
						//f[7-cc+8] = f[7-cc+8] + 1;
						pcount += 1;
					}
				}
				
				int j;
				float minx, maxx, miny, maxy;
				minx = miny = FMAX;
				maxx = maxy = -FMAX;
				for(j = 0; j < nump; j++) {
					MyPoint pp = tstr.p.get(j);
					
					minx = Math.min(minx, pp.X);
					maxx = Math.max(maxx, pp.X);
					miny = Math.min(miny, pp.Y);
					maxy = Math.max(maxy, pp.Y);
					
					//if(pp.X > 0) f[17]++;
					//if(pp.Y > 0) f[18]++;
				}
				
				float midx = (minx + maxx)/2;
				float midy = (miny + maxy)/2;
				for(j = 0; j < nump; j++) {
					MyPoint pp = tstr.p.get(j);
					if(pp.X > midx) f[17]++;
					if(pp.Y > midy) f[18]++;
				}
			}
		}
		
		if(nums >= 2) {
			
			if( (d.s.get(0).rightX < d.s.get(1).leftX) && (d.s.get(0).leftX < d.s.get(1).leftX) ){
				f[16] = pcount;
			} 
			else if( (d.s.get(1).rightX < d.s.get(0).leftX) && (d.s.get(1).leftX < d.s.get(0).leftX) ) {
				f[16] = pcount;
			}
		}
		
		/*float fsum = 0;
		for(i = 0; i < FDIM; i++){
			fsum = fsum + f[i];
		}
		for(i = 0; i < FDIM; i++){
			f[i] = f[i] / fsum;
		}*/
		
		String fss = "";
		for(int k = 0; k < FDIM; k++){
			fss = fss + f[k] + " ";
		}
		Log.v("Fcom Inside", d.ID + ": " + fss);
		
		return f;
	}
	
	public void loadTrainingSet(File[] files) {
		
		totalFiles = files.length;
		
		tset = new float[12][totalFiles][FDIM];
		
		try{
			int i, j, k;
			for(i = 0; i < totalFiles; i++) {
				
				FileInputStream fstream = new FileInputStream(files[i]);
				BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
				String strLine;
				Log.v("FeatureComputer", "Loading feature file: " + files[i].getName());
				
				for(j = 0; j < 12; j++) {
					
					strLine = br.readLine();
					StringTokenizer strtok = new StringTokenizer(strLine);		
					
					for(k = 0; k < FDIM; k++) {
						float ftmp = Float.parseFloat(strtok.nextToken());	
						tset[j][i][k] = ftmp;
					}
				}
				
				br.close();
				fstream.close();
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
	}
	
	public int[] classifyFileUnused(int findex) {
		
		int[] ret = new int[12];
		int di, dj, fi;
		float df;
		int K = (int)Math.sqrt(totalFiles);
		
		//testing file: findex.mc.txt
		for(di = 0; di < 12; di++){
			
			dvals.clear();
			
			for(dj = 0; dj < 12; dj++){
			
				for(fi = 0; fi < totalFiles; fi++) {
					
					if(fi == findex) continue;
					
					df = getDistance(tset[di][findex], tset[dj][fi]);
					
					dvals.add(new MyTouple(dj, df));
				}
			}
			
		    Collections.sort(dvals, new Comparator<MyTouple>() {
		        @Override 
		        public int compare(MyTouple p1, MyTouple p2) {
		        	
		        	if(p1.val > p2.val) return 1;
		        	else if(p1.val < p2.val) return -1;
		            return 0;
		        }

		    });
			
			ret[di] = getMajority(dvals, K);
			
			String dmsg = "Digit [" + di + "]: ";
			for(int kk = 0; kk < K; kk++) {
				dmsg = dmsg + dvals.get(kk).val + ", " + dvals.get(kk).id + "; ";
			}
			dmsg = dmsg + "\n";
			Log.v("booo", dmsg);
		}	
		
		return ret;
	}
	
	
	public int getMajority(ArrayList<MyTouple> dval, int k)
	{
		int[] r = new int[12];
		int i, tmp;
		
		int maxid = 0, maxval = 0;
		
		for(i = 0; i < 12; i++) r[i] = 0;
		
		for(i = 0; i < k && i < dval.size(); i++){
			tmp = dval.get(i).id;
			r[tmp]++;
			if(r[tmp] > maxval) {
				maxval = r[tmp];
				maxid = tmp;
			}
		}
		
		return maxid;
	}
	
	public int[] classifyFile(int findex) {
		
		int[] ret = new int[12];
		
		int di, fi, dj;
		int tFiles = totalFiles;
		
		float[][] dmat = new float[12][12];
		
		//testing file: findex.mc.txt
		for(di = 0; di < 12; di++){
			
			for(dj = 0; dj < 12; dj++){
				
				dmat[di][dj] = FMAX;  //Float.MAX_VALUE;
			
				float[] df = new float[tFiles];
				
				for(fi = 0; fi < tFiles; fi++) {
					
					df[fi] = getDistance(tset[di][findex], tset[dj][fi]);
				}
				
				if(findex < tFiles)
				df[findex] = FMAX;
				dmat[di][dj] = getMean(df, tFiles, findex);	
			}
		}
		
		float minval = FMAX; //Float.MAX_VALUE;
		
		for(di = 0; di < 12; di++){
			
			ret[di] = -1;
			minval = FMAX; //Float.MAX_VALUE;
			
			for(dj = 0; dj < 12; dj++){
				if(dmat[di][dj] < minval){
					ret[di] = dj;
					minval = dmat[di][dj];
				}
			}
		}
		
		
		return ret;
	}
	
	float getMean(float[] df, int totalFiles, int findex)
	{
		float ret = FMAX; //Float.MAX_VALUE;
		
		Arrays.sort(df);
		
		float sum = 0;
		int k_lim =  (int)Math.sqrt(totalFiles);
		
		if(k_lim <= 0) k_lim = 3;
		
		int k = 0;
		
		k_lim = 1;
		
		for(int i = 0; i < totalFiles && k < k_lim; i++){
			
			if(i == findex) continue;
			
			sum = sum + df[i];
			k++;
		}
		ret = sum / k;
		
		return ret;
	}
	
	float getDistance(float[] u, float[] v)
	{
		float sum = 0;
		for(int i = 0; i < FDIM; i++){
			sum = sum + (u[i] - v[i]) * (u[i] - v[i]);
		}
		return sum;
	}
	
}


