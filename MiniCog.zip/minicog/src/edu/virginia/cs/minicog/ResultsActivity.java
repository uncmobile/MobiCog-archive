package edu.virginia.cs.minicog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

public class ResultsActivity extends Activity {

	private ProgressBar pb1, pb2, pb3, pb4, pb5;
	private RatingBar rb1, rb2, rb3, rb4, rb5;
	private TextView tv1, tv2, tv3, tv4, tv5;
	
	private FeatureComputer fcom;
	private Handler handler;
	private static int DIGIT_VAL = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_results);
		
		handler = new Handler();
		fcom = new FeatureComputer();
		
		this.callTestOnlyLastFile();
		
		rb1 = (RatingBar) findViewById(R.id.ratingBar1);
		rb2 = (RatingBar) findViewById(R.id.ratingBar2);
		rb3 = (RatingBar) findViewById(R.id.ratingBar3);
		rb4 = (RatingBar) findViewById(R.id.ratingBar4);
		rb5 = (RatingBar) findViewById(R.id.ratingBar5);
		
		tv1 = (TextView) findViewById(R.id.label1);
		tv2 = (TextView) findViewById(R.id.label2);
		tv3 = (TextView) findViewById(R.id.label3);
		tv4 = (TextView) findViewById(R.id.label4);
		tv5 = (TextView) findViewById(R.id.label5);
		
		rb1.setMax(100);
		rb2.setMax(100);
		rb3.setMax(100);
		rb4.setMax(100);
		rb5.setMax(100);
		
		setAllProgressValues();
	}

	void setAllProgressValues()
	{
		
		/*RecallActivity.RECALL_TOTAL = 2;
		ClockDrawActivity.DIGIT_POS = 12;
		ClockDrawActivity.HOUR_ERR = 84;
		ClockDrawActivity.MIN_ERR = 99;*/
		
		//word recall
		float v1 = Math.min(100f, RecallActivity.RECALL_TOTAL * 100.0f / 3.0f);
		rb1.setProgress((int)v1);
		tv1.setText(RecallActivity.RECALL_TOTAL + " of 3");
		
		//digit position
		float v2 = Math.min(100f, ClockDrawActivity.DIGIT_POS * 100.0f / 12.0f);
		rb2.setProgress((int)v2);
		tv2.setText(ClockDrawActivity.DIGIT_POS + " of 12");
		
		
		
		//hour
		rb4.setProgress(ClockDrawActivity.HOUR_ERR);
		tv4.setText(ClockDrawActivity.HOUR_ERR + "% close");
		
		//min
		//pb5.setProgress(ClockDrawActivity.MIN_ERR);
		rb5.setRating(ClockDrawActivity.MIN_ERR);
		tv5.setText(ClockDrawActivity.MIN_ERR + "% close");
		
	}
	
	
	void updateProgressStatus()
	{
		Log.v("Results Activity", "updating progress bar");
    	
		handler.post(new Runnable() {
			int val = DIGIT_VAL;
			@Override
			public void run() {
				rb3.setProgress((int)(val * 100.0f / 12.0f));
				tv3.setText(val + " of 12");
				rb3.invalidate();
				tv3.invalidate();
			}
		});
	}
	
	void callTestOnlyLastFile()
	{
		Thread t = new Thread()
		{
			@Override
			public void run() {
				try{
					
		        	String foldername = Environment.getExternalStorageDirectory()+MainActivity.MONICOG_FOLDER;
		        	File f = new File(foldername);
		        	if(f.exists() == false) {
		        		Log.v("Compute kActivity", "Creating MiniCog folder for saving files");
		        		f.mkdir();
		        	}
		        	else {
		        		Log.v("Compute Activity", "MiniCog Folder Exists");
		        	}
					
	        		File[] files = f.listFiles(new FilenameFilter() {
	        		    public boolean accept(File f, String name) {
	        		        return name.toLowerCase().endsWith(".mc.txt");
	        		    }
	        		});
					
	        		File tin = new File(foldername + "/0.mc");
	        		File tout = new File(foldername + "/0.mc.txt");
	        		
	        		callExtractFeatureFilesInner(tin, tout);
	        		
					fcom.loadTrainingSet(files);
					int[] res = fcom.classifyFile(0); 
					
					String msg =  "Test Result: \n";
					DIGIT_VAL = 0;
					for(int ri = 0; ri < 12; ri++){
						msg = msg + (ri+1) + " -> " + (1+res[ri]) + "\n";
						if(ri == res[ri]) DIGIT_VAL++;
					}
					
					Log.v("Restuls Activity", msg);
					//updateProgressStatus();
					
					rb3.setProgress((int)(DIGIT_VAL * 100.0f / 12.0f));
					tv3.setText(DIGIT_VAL + " of 12");
					rb3.invalidate();
					tv3.invalidate();
        			
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
		};
		t.setPriority(Thread.MAX_PRIORITY);
		t.start();
	}
	
	void callExtractFeatureFilesInner(File infile, File outfile)
	{
		try{
			ObjectInputStream inp = new ObjectInputStream(new 
					FileInputStream(infile));
			
			FileOutputStream fout = new FileOutputStream(outfile);
			OutputStreamWriter mwriter = new OutputStreamWriter(fout);
			
			MyDigit tdigit = new MyDigit();
			
			for(int i = 0; i < 12; i++){
				tdigit = (MyDigit) inp.readObject();
				float fvec[] = fcom.getFetures(tdigit);
				String fvstr = "";
				for(int di = 0; di < FeatureComputer.FDIM; di++){
					fvstr = fvstr + fvec[di] + " ";
				}
				mwriter.write(fvstr + "\n");
				Log.v("Compute Activity", "" + (i+1) + ": " + fvstr);
			}
			
			inp.close();
			mwriter.close();
			fout.close();		
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void onExitButtonClicked(View v){
	    if(v.getId() == R.id.buttonExit){
	        Log.v("Results Activity", "Exit button clicked.");
	        Intent intent = new Intent(Intent.ACTION_MAIN);
	        intent.addCategory(Intent.CATEGORY_HOME);
	        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	        startActivity(intent);
	    }
	}
	
	public void onDetailsButtonClicked(View v){
	    if(v.getId() == R.id.buttonDetails){
	        Log.v("Results Activity", "Details button clicked.");
	        Intent intent = new Intent(this, ComputeActivity.class);
	        startActivity(intent);
	    }
	}
	
	
}
