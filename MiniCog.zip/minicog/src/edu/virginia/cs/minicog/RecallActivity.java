package edu.virginia.cs.minicog;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RecallActivity extends Activity {

	protected static final int RESULT_SPEECH = 1;
	protected static final int RESULT_SPEECH2 = 2;
	protected static final int RESULT_SPEECH3 = 3;
	
	TextView tv1, tv2, tv3;
	EditText et1, et2, et3;
	
	public static int RECALL_1 = 0;
	public static int RECALL_2 = 0;
	public static int RECALL_3 = 0;
	public static int RECALL_TOTAL = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_recall);
		tv1 = (TextView) this.findViewById(R.id.textViewWord1);
		tv2 = (TextView) this.findViewById(R.id.textViewWord2);
		tv3 = (TextView) this.findViewById(R.id.textViewWord3);
		
		et1 = (EditText) this.findViewById(R.id.editText1);
		et2 = (EditText) this.findViewById(R.id.editText2);
		et3 = (EditText) this.findViewById(R.id.editText3);
		
		//setupEditTexts(); 
		
	}

	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.recall, menu);
		return true;
	}

	public void readDigitObjectsFromFile() 
	{
		try {
        	String foldername = Environment.getExternalStorageDirectory()+MainActivity.MONICOG_FOLDER;
        	File f = new File(foldername);
        	if(f.exists() == false){
        		Log.v("RecallActivity", "Creating MiniCog folder for saving files");
        		f.mkdir();
        	}
        	else {
        		Log.v("RecallActivity", "MiniCog Folder Exists");
        	}
        	
        	String fname = MainActivity.LAST_FILE;
        	
        	MyDigit tdigit = new MyDigit();
			ObjectInputStream inp = new ObjectInputStream(new FileInputStream(foldername + "/" + fname));
			for(int i = 0; i < 12; i++){
				tdigit = (MyDigit) inp.readObject();
				ClockDrawActivity.printDigitObject(tdigit);
			}
			inp.close();
		
			Log.v("RecallActivity", "Read objects from file");
		} catch (Exception e) {
			e.printStackTrace();
		} 		
	}
	
	public void onSubmitClicked(View v){
	    if(v.getId() == R.id.buttonPage3Submit){

	        Log.v("Recall Activity", "Next button clicked.");
	        Intent intent = new Intent(this, ResultsActivity.class);
	        startActivity(intent);
	    }
	}
	
	public void onWordClicked(View v){
	    if(v.getId() == R.id.buttonWord1){
	        Log.v("RecallActivity", "word 1 button clicked.");
	        Intent intent = new Intent(
                    RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");

            try {
                startActivityForResult(intent, RESULT_SPEECH);
                tv1.setText("A. ");
            } catch (ActivityNotFoundException a) {
                Toast t = Toast.makeText(getApplicationContext(),
                        "Opps! Your device doesn't support Speech to Text",
                        Toast.LENGTH_SHORT);
                t.show();
            }
	    }
	    if(v.getId() == R.id.buttonWord2){
	        Log.v("RecallActivity", "word 2 button clicked.");
	        Intent intent = new Intent(
                    RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");

            try {
                startActivityForResult(intent, RESULT_SPEECH2);
                tv2.setText("A. ");
            } catch (ActivityNotFoundException a) {
                Toast t = Toast.makeText(getApplicationContext(),
                        "Opps! Your device doesn't support Speech to Text",
                        Toast.LENGTH_SHORT);
                t.show();
            }
	    }
	    if(v.getId() == R.id.buttonWord3){
	        Log.v("RecallActivity", "word 3 button clicked.");
	        Intent intent = new Intent(
                    RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");

            try {
                startActivityForResult(intent, RESULT_SPEECH3);
                tv3.setText("A. ");
            } catch (ActivityNotFoundException a) {
                Toast t = Toast.makeText(getApplicationContext(),
                        "Opps! Your device doesn't support Speech to Text",
                        Toast.LENGTH_SHORT);
                t.show();
            }
	    }
	}
	
	boolean matchWords(ArrayList<String> text, int pos)
	{
		int len = text.size();
		String w = MainActivity.WORDLIST[MainActivity.WORDINDEX][pos];
		for(int i = 0; i < len; i++){
			if(text.get(i).equalsIgnoreCase(w)){
				text.set(0, w);
				Log.v("Recall Activity", "The i = " + i);
				return true;
			}
		}
		return false;
	}
	
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
 
        switch (requestCode) {
        case RESULT_SPEECH: {
            if (resultCode == RESULT_OK && null != data) {
 
                ArrayList<String> text = data
                        .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                
                RECALL_1 = 0;
                String rslt = " (wrong)";
                if(matchWords(text, 0)){
                	rslt = " (correct!)";
                	RECALL_1 = 1;
                }
                
                tv1.setText("A. " + text.get(0) + rslt);
            }
            else {
            	tv1.setText("A. ???");
            }
            break;
        }
        case RESULT_SPEECH2: {
            if (resultCode == RESULT_OK && null != data) {
 
                ArrayList<String> text = data
                        .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String rslt = " (wrong)";
                RECALL_2 = 0;
                if(matchWords(text, 1)){
                	rslt = " (correct!)";
                	RECALL_2 = 1;
                }	
                tv2.setText("A. " + text.get(0) + rslt);
            }
            else {
            	tv2.setText("A. ???");
            }
            break;
        }
        case RESULT_SPEECH3: {
            if (resultCode == RESULT_OK && null != data) {
 
                ArrayList<String> text = data
                        .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String rslt = " (wrong)";
                RECALL_3 = 0;
                if(matchWords(text, 2)){
                	rslt = " (correct!)";
                	RECALL_3 = 1;
                }
                tv3.setText("A. " + text.get(0) + rslt);
            }
            else {
            	tv3.setText("A. ???");
            }
            break;
        }
 
        }
        
        RECALL_TOTAL = RECALL_1 + RECALL_2 + RECALL_3;
        
    }
	
}
