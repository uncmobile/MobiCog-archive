package edu.virginia.cs.minicog;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

	public static int HH = 10;
	public static int MM = 15;
	
	public static int WORDINDEX = 0;
	public static String[][] WORDLIST = new String[][]{
		{"Banana", "Sunrise", "Chair"},
		{"Daughter", "Heaven", "Mountain"},
		{"Village", "Kitchen", "Baby"},
		{"River", "Nation", "Finger"},
		{"Captain", "Garden", "Picture"},
		{"Leader", "Season", "Table"}
	}; 
	
	public static String MONICOG_FOLDER = "/MiniCogFolder";
	public static String LAST_FILE = "0.mc";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		WORDINDEX = ((int)(Math.random() * 6000)) % 6;
		TextView tv1 = (TextView)findViewById(R.id.tvWord1);
		TextView tv2 = (TextView)findViewById(R.id.tvWord2);
		TextView tv3 = (TextView)findViewById(R.id.tvWord3);
		
		tv1.setText(WORDLIST[WORDINDEX][0]);
		tv2.setText(WORDLIST[WORDINDEX][1]);
		tv3.setText(WORDLIST[WORDINDEX][2]);
		
		HH = 1 + ((int)(Math.random() * 1200)) % 12;
		MM = (1 + ((int)(Math.random() * 1200)) % 11) * 5;
		
		Log.v("MainActivity", "HH:MM = " + HH + ":" + MM);
			
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void onPage1DoneClicked(View v){
	    if(v.getId() == R.id.buttonPage1){
	        Log.v("MainActivity", "Done button clicked.");
	        Intent intent = new Intent(this, ClockDrawActivity.class);
	        startActivity(intent);

	    }
	}
	
}
