package edu.virginia.cs.minicog;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.ObjectOutputStream;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;

public class ClockDrawActivity extends Activity implements OnTouchListener {

	ImageView imageView;
	
	//drawing path
	private Path drawPath;
	//drawing and canvas paint
	private Paint drawPaint;
	//initial color
	private int paintColor =  Color.DKGRAY;//0xFF660000;
	
	//canvas
	private Canvas drawCanvas;
	//canvas bitmap
	private Bitmap canvasBitmap;
	
	int w = 340;
	float rout = w/2;
	
	public static int DIGIT_POS = 0;
	public static int HOUR_ERR = 0;
	public static int MIN_ERR = 0;
	
	public MyDigit[] myDigits = new MyDigit[12];
	public MyStroke[] hands = new MyStroke[2];
	private MyStroke curStroke = new MyStroke();
	private MyPoint curPoint = new MyPoint();
	private int STATE = 0;
	
	boolean isItHand(MyStroke s) {
		
		if(s.p.size() < 2) return false;
		
		MyPoint p1 = s.p.get(0);
		MyPoint p2 = s.p.get(s.p.size()-1);
		MyPoint pc = new MyPoint(rout, rout);
		
		float d1 = p1.dsqr(pc);
		float d2 = p2.dsqr(pc);
		float rr = (rout * 0.20f) * (rout * 0.20f); //size of the inner circle
		
		if(d1 < rr || d2 < rr) 
			return true;
		
		return false;
	}
	
	void insertStrokeToDigit(MyStroke s) {
		
		float mindist = s.v.dsqr(myDigits[0].loc);
		int index = 0;
		
		for(int i = 1; i < 12; i++){
			float dd = s.v.dsqr(myDigits[i].loc);
			if(dd < mindist) {
				mindist = dd;
				index = i;
			}
		}
		
		myDigits[index].s.add(s);
		
		this.debugCircle(myDigits[index].loc.X, myDigits[index].loc.Y);
		
		float a = 0.85f;
		myDigits[index].loc.X = a * myDigits[index].loc.X + (1-a) * s.v.X;
		myDigits[index].loc.Y = a * myDigits[index].loc.Y + (1-a) * s.v.Y;
		
	}
	
	/**
	 * This method converts dp unit to equivalent pixels, depending on device density. 
	 * 
	 * @param dp A value in dp (density independent pixels) unit. Which we need to convert into pixels
	 * @param context Context to get resources and device specific display metrics
	 * @return A float value to represent px equivalent to dp depending on device density
	 */
	public static float convertDpToPixel(float dp, Context context){
	    Resources resources = context.getResources();
	    DisplayMetrics metrics = resources.getDisplayMetrics();
	    float px = dp * (metrics.densityDpi / 160f);
	    return px;
	}
	
	/**
	 * This method converts device specific pixels to density independent pixels.
	 * 
	 * @param px A value in px (pixels) unit. Which we need to convert into db
	 * @param context Context to get resources and device specific display metrics
	 * @return A float value to represent dp equivalent to px value
	 */
	public static float convertPixelsToDp(float px, Context context){
	    Resources resources = context.getResources();
	    DisplayMetrics metrics = resources.getDisplayMetrics();
	    float dp = px / (metrics.densityDpi / 160f);
	    return dp;
	}


	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_clockdraw);
		
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int width = size.x;
		Log.v("ClockActivity", "Display Width = " + width);
		
		float dscale = getResources().getDisplayMetrics().density;
		Log.v("ClockActivity", "scale = " + dscale);
		
		w = (int) (0.95 * width / dscale);
		rout = w/2;
		
		imageView = (ImageView) this.findViewById(R.id.imageView1);
		imageView.getLayoutParams().height = (int) convertDpToPixel(w, this);
		imageView.getLayoutParams().width = (int) convertDpToPixel(w, this);
		
		TextView tv1 = (TextView)findViewById(R.id.tvTitle2);
		tv1.setText("Task 2: Draw " + MainActivity.MM + " min past " + MainActivity.HH + ":00");

		
		setupDrawing();
	}

	void debugCircle(float cx, float cy)
	{
	    Paint center = new Paint();
	    center.setColor(Color.GREEN);
	    drawCanvas.drawCircle(cx, cy, rout * 0.02f, center);
	}
	
	//This is for DEBUG
	void drawClockHands()
	{
		Paint tPaint = new Paint();
		tPaint.setColor(Color.GREEN);
		tPaint.setAntiAlias(true);
		tPaint.setStrokeWidth(3);
		tPaint.setStyle(Paint.Style.STROKE);
		tPaint.setStrokeJoin(Paint.Join.ROUND);
		tPaint.setStrokeCap(Paint.Cap.ROUND);
		
		int i;
		for(i = 0; i < 2; i++){
			if(hands[i].p.size() >= 2){
				float startX = rout;
				float startY = rout;
				int len = hands[i].p.size();
				float stopX = hands[i].p.get(len-1).X;
				float stopY = hands[i].p.get(len-1).Y;
				drawCanvas.drawLine(startX, startY, stopX, stopY, tPaint);
			}
		}
	}
	
	void computeHandErrors()
	{
		double a1, a2, b1, b2;
		double a[] = {60, 30, 0, 330, 300, 270, 240, 210, 180, 150, 120, 90};
		
		int len = hands[0].p.size();
		a1 = Math.atan2(-hands[0].p.get(len-1).Y + rout, hands[0].p.get(len-1).X - rout);
		
		len = hands[1].p.size();
		a2 = Math.atan2(-hands[1].p.get(len-1).Y + rout, hands[1].p.get(len-1).X - rout);
		
		if(a1 < 0) a1 = a1 + 2 * Math.PI;
		if(a2 < 0) a2 = a2 + 2 * Math.PI;
		
		a1 = a1 * 180 / Math.PI;
		a2 = a2 * 180 / Math.PI;
		
		
		b1 = a[MainActivity.HH - 1];
		b2 = a[MainActivity.MM/5 - 1];
		
		Log.v("Clock Act", "a1 = " + a1 + "a2 = " + a2 + "b1 = " + b1 + "b2 = " + b2);
		
		double e1, e2, e3, e4;
		
		e1 = Math.abs(a1 - b1); if(e1 > 180) e1 = 360 - e1;
		e2 = Math.abs(a2 - b2); if(e2 > 180) e2 = 360 - e2;
		
		e3 = Math.abs(a1 - b2); if(e3 > 180) e3 = 360 - e3;
		e4 = Math.abs(a2 - b1); if(e4 > 180) e4 = 360 - e4;
		
		if((e1+e2) < (e3+e4)){
			HOUR_ERR = (int)(e1 * 100 / 180);
			MIN_ERR = (int)(e2 * 100 / 180);
		}
		else {
			HOUR_ERR = (int)(e3 * 100 / 180);
			MIN_ERR = (int)(e4 * 100 / 180);
		}
		
		HOUR_ERR = 100 - HOUR_ERR;
		MIN_ERR = 100 - MIN_ERR;
	}
	
	void setupDrawing()
	{
		drawPath = new Path();
		
		drawPaint = new Paint();
		drawPaint.setColor(paintColor);
		drawPaint.setAntiAlias(true);
		drawPaint.setStrokeWidth(2);
		drawPaint.setStyle(Paint.Style.STROKE);
		drawPaint.setStrokeJoin(Paint.Join.ROUND);
		drawPaint.setStrokeCap(Paint.Cap.ROUND);
		
		new Paint(Paint.DITHER_FLAG);
		
		canvasBitmap = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
		
		drawCanvas = new Canvas(canvasBitmap);
		
		imageView.setBackgroundColor(Color.WHITE);
		
	    imageView.setImageBitmap(canvasBitmap);
	    	    
	    initDigitStrokes();
	    drawEmptyCircles();
	    
	    imageView.setOnTouchListener(this);
	    
	}
	
	void initDigitStrokes() 
	{
		int i, j;
		
	    for(i = 300, j = 0; j < 12; i = (i+30)%360, j++){
	    	double angl = i * Math.PI / 180.0;
	    	
	    	int px = (int) ( rout * (1 + Math.cos(angl)) );
	    	int py = (int) ( rout * (1 + Math.sin(angl)) );
	    	
	    	myDigits[j] = new MyDigit();
	    	myDigits[j].ID = j+1;
	    	myDigits[j].loc = new MyPoint(px, py);
	    }	
	    
	    hands[0] = new MyStroke();
	    hands[1] = new MyStroke();
	}
	
	void drawEmptyCircles()
	{
		STATE = 0;
		
		float rinr = rout * 0.2f;
		float rdig = rout * 0.015f;
		
		drawCanvas.drawColor(Color.WHITE);
		drawCanvas.drawCircle(rout, rout , rout, drawPaint);
	    
	    Paint center = new Paint();
	    center.setColor(Color.LTGRAY);
	    drawCanvas.drawCircle(rout, rout , rinr, center); //inner circle
	    
	    for(int i = 0; i < 360; i+= 30){
	    	double angl = i * Math.PI / 180.0;
	    	int px = (int) ( rout * (1 + Math.cos(angl)) );
	    	int py = (int) ( rout * (1 + Math.sin(angl)) );
	    	drawCanvas.drawCircle(px, py , rdig, center);
	    }
	    
	    imageView.invalidate();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.clock_draw, menu);
		return true;
	}

	public void writeDigitObjectsToFile(String fname) throws Exception 
	{		
		try {
        	String foldername = Environment.getExternalStorageDirectory()+MainActivity.MONICOG_FOLDER;
        	File f = new File(foldername);
        	if(f.exists() == false){
        		Log.v("ClockActivity", "Creating MiniCog folder for saving files");
        		f.mkdir();
        	}
        	else {
        		Log.v("ClockActivity", "MiniCog Folder Exists");
        	}
        	
        	if(fname == null){
        		File[] files = f.listFiles(new FilenameFilter() {
        		    public boolean accept(File f, String name) {
        		        return name.toLowerCase().endsWith(".mc");
        		    }
        		});
        		fname = "" + files.length + ".mc";
        	}
        	
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(foldername + "/" + fname));
			for(int i = 0; i < 12; i++){
				out.writeObject(myDigits[i]);	
				//printDigitObject(myDigits[i]);
			}
			out.close();
		
			Log.v("ClockActivity", "Wrote objects to file");
			Toast.makeText(this, "Saved as: " + fname, Toast.LENGTH_SHORT).show();
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} 
	}
	
	public static void printDigitObject(MyDigit m)
	{
		if(m.s.size() <= 0) return;
		
		int tot = m.s.get(0).p.size();
		for(int i = 0; i < tot; i++){
			System.out.print(m.s.get(0).p.get(i).X + " " + m.s.get(0).p.get(i).Y + "; ");
		}
		System.out.println("");
	}
	
	public void onPage2DoneClicked(View v){
	    if(v.getId() == R.id.buttonPage2){
	        Log.v("ClockDrawActivity", "Submit button clicked.");
        	try{
        		writeDigitObjectsToFile(MainActivity.LAST_FILE);
        		
    	        int i;
    	        DIGIT_POS = 0;
    	        for(i = 0; i < 12; i++){
    	        	if(myDigits[i].s.size() > 0){
    	        		DIGIT_POS++;	
    	        	}
    	        }
        		
        		
        		Intent intent = new Intent(this, RecallActivity.class);
		        startActivity(intent);
        	}catch (Exception ex){
        		ex.printStackTrace();
        	}
	    }
	}
	
	public void onPage2ClearClicked(View v){
	    if(v.getId() == R.id.buttonPage2Clear){
	        Log.v("ClockDrawActivity", "Clear button clicked.");
	        initDigitStrokes();
	        drawEmptyCircles();	
	    }
	}

	public void onPage2SaveClicked(View v){
	    if(v.getId() == R.id.buttonPage2Save){
	        Log.v("ClockDrawActivity", "Save button clicked.");
	        
	        int i;
	        for(i = 0; i < 12; i++){
	        	if(myDigits[i].s.size() <= 0){
	        		Toast.makeText(this, "Digit missing: " + (i+1) + ". File not saved.", Toast.LENGTH_SHORT).show();
	        		return;
	        	}
	        }
	        
        	try{
        		writeDigitObjectsToFile(null);
        	}catch (Exception ex){
        		ex.printStackTrace();
        	}
	    }
	}
	

	
	public boolean onTouch(View v, MotionEvent event) {
	
		if(v.getId() != R.id.imageView1){
			Log.v("onTOuch", "not image view");
			return false;
		}
		
		float dscale = getResources().getDisplayMetrics().density;
		Log.v("MainActivity", "scale = " + dscale);
		
		float touchX = event.getX()/dscale;
		float touchY = event.getY()/dscale;
		
		Log.v("Touch", "" + touchX + ", " + touchY);
		
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
		    drawPath.moveTo(touchX, touchY);
		    
		    curPoint = new MyPoint(touchX, touchY);
		    curStroke = new MyStroke();
		    curStroke.p.add(curPoint);
		    
		    break;
		    
		case MotionEvent.ACTION_MOVE:
		    drawPath.lineTo(touchX, touchY);
		    drawCanvas.drawPath(drawPath, drawPaint);
		    drawPath.reset();
		    drawPath.moveTo(touchX, touchY);
		    
		    curPoint = new MyPoint(touchX, touchY);
		    curStroke.p.add(curPoint);
		    break;
		    
		case MotionEvent.ACTION_UP:
			
			curStroke.updateCOG();
			drawCanvas.drawPath(drawPath, drawPaint);
			
			if(STATE == 0){
				if(isItHand(curStroke)){
					STATE = 1;
					hands[0] = curStroke;
					drawClockHands();
					Log.v("ClockAct", "Its 1st hand");
				}
				else{
					curStroke.normalizePoints();
					insertStrokeToDigit(curStroke);
				}
			}
			else {
				if(isItHand(curStroke)){
					hands[1] = curStroke;
					drawClockHands();
					Log.v("ClockAct", "Its 2nd hand");
					computeHandErrors();
				}
			}
			
			drawPath.reset();
		    break;
		    
		default:
		    return false;
		}
		
		imageView.invalidate();
		return true;
		
	}
	
}
