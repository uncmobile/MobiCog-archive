package edu.virginia.cs.minicog;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class ComputeActivity extends Activity {

	TextView tvstatus;
	private Handler handler;
	
	public static String TEMP_MSG = "";
	public static boolean DOALL = false;
	
	public FeatureComputer fcom;
	
	void updateStatus()
	{
		Log.v("Compute Activity", "Done " + TEMP_MSG);
    	
		handler.post(new Runnable() {
			String msgg = TEMP_MSG;
			@Override
			public void run() {
				tvstatus.append(msgg + "\n");
				tvstatus.invalidate();
			}
		});
	}
	
	void callCrossValidation()
	{
		Thread t = new Thread()
		{
			@Override
			public void run() {
				try{
					
		        	String foldername = Environment.getExternalStorageDirectory()+MainActivity.MONICOG_FOLDER;
		        	File f = new File(foldername);
		        	if(f.exists() == false) {
		        		Log.v("Compute kActivity", "Creating MiniCog folder for saving files");
		        		f.mkdir();
		        	}
		        	else {
		        		Log.v("Compute Activity", "MiniCog Folder Exists");
		        	}
					
	        		File[] files = f.listFiles(new FilenameFilter() {
	        		    public boolean accept(File f, String name) {
	        		        return name.toLowerCase().endsWith(".mc.txt");
	        		    }
	        		});
	        		
	        		long t1, t2; 
	        		
	        		t1= System.currentTimeMillis();
	        		
					fcom.loadTrainingSet(files);
					
					t2 = System.currentTimeMillis();
					
					Log.v("Compute Activity", "Traing Set Loading Time: " + (t2 - t1) + " ms");
					
					int[][] cmat = new int[12][12];
					int i, j;
					int ferr = 0;
					
					t1 = System.currentTimeMillis();
										
					for(i = 0; i < fcom.totalFiles; i++) {
						
						int[] res = fcom.classifyFile(i);
						for(j = 0; j < 12; j++){
							if(res[j]>=0)
							cmat[j][res[j]]++;
							if(j != res[j]) ferr++;
						}
						TEMP_MSG =  "Test Result: " + files[i].getName() + "\n";
						for(int ri = 0; ri < 12; ri++){
							TEMP_MSG = TEMP_MSG + (ri+1) + "-" + (1+res[ri]) + "; ";
						}
						TEMP_MSG = TEMP_MSG + "\n";
	        			//updateStatus();
					}
					t2 = System.currentTimeMillis();
					Log.v("Compute Activity", "Classification Time: " + ((t2 - t1)*1.0f/fcom.totalFiles) + " ms");
					
					TEMP_MSG = "Confusion Matrix: \n";
					for(i = 0; i < 12; i++){
						for(j = 0; j < 12; j++){
							TEMP_MSG = TEMP_MSG + cmat[i][j] + " ";
						}
						TEMP_MSG = TEMP_MSG + "\n";
					}
					
					TEMP_MSG = TEMP_MSG + "Error: " + ((ferr * 100.0f)/(12*fcom.totalFiles)) + "\n";
					
					updateStatus();
					
					processConfMat(cmat);
        			
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
		};
		t.start();
	}
	
	void processConfMat(int[][] c)
	{
		/*int[] tp = new int[12];
		int[] tn = new int[12];
		int[] fp = new int[12];
		int[] fn = new int[12];*/
		
		int tps = 0, tns = 0, fps = 0, fns = 0;
		
		int i, j, k;
		for(i = 0; i < 12; i++) {
			for(j = 0; j < 12; j++){
				//classified: i -> j
				for(k = 0; k < 12; k++){
					
					if(i == j){
						if(i == k) {
							tps += c[i][j];
						}
						else {
							//tp[i] += c[i][j];
							tns += c[i][j];
						}
						
					}
					else {
						
						if(i == k){
							fns += c[i][j];
							//fp[j] += c[i][j];
						}
						else if(j == k) {
							//fn[i] += c[i][j];
							fps += c[i][j];
						}
						else{
							tns += c[i][j];
						}
						
					}
					
					
				}
			}
		}
		
		
		
		
		float acc = (tps + tns) * 100f / (tps + fns + fps + tns);
		TEMP_MSG = "Conf Mat: \nTP = " + tps + " FN = " + fns + "\nFP = " + fps + " TN = " + tns + "\nAcc = " + acc + "\n";
		Log.v("mat", TEMP_MSG);
		updateStatus();
		
		
	}
	
	
	void callTestOnlyLastFile()
	{
		Thread t = new Thread()
		{
			@Override
			public void run() {
				try{
					
		        	String foldername = Environment.getExternalStorageDirectory()+MainActivity.MONICOG_FOLDER;
		        	File f = new File(foldername);
		        	if(f.exists() == false) {
		        		Log.v("Compute kActivity", "Creating MiniCog folder for saving files");
		        		f.mkdir();
		        	}
		        	else {
		        		Log.v("Compute Activity", "MiniCog Folder Exists");
		        	}
					
	        		File[] files = f.listFiles(new FilenameFilter() {
	        		    public boolean accept(File f, String name) {
	        		        return name.toLowerCase().endsWith(".mc.txt");
	        		    }
	        		});
					
	        		File tin = new File(foldername + "/0.mc");
	        		File tout = new File(foldername + "/0.mc.txt");
	        		
	        		callExtractFeatureFilesInner(tin, tout);
	        		
					fcom.loadTrainingSet(files);
					int[] res = fcom.classifyFile(0); 
					
					TEMP_MSG =  "Test Result: \n";
					for(int ri = 0; ri < 12; ri++){
						TEMP_MSG = TEMP_MSG + (ri+1) + " -> " + (1+res[ri]) + "\n";
					}
					
        			updateStatus();
        			
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
		};
		t.start();
	}
	
	void callExtractFeatureFilesInner(File infile, File outfile)
	{
		try{
			ObjectInputStream inp = new ObjectInputStream(new 
					FileInputStream(infile));
			
			FileOutputStream fout = new FileOutputStream(outfile);
			OutputStreamWriter mwriter = new OutputStreamWriter(fout);
			
			MyDigit tdigit = new MyDigit();
			
			for(int i = 0; i < 12; i++){
				tdigit = (MyDigit) inp.readObject();
				float fvec[] = fcom.getFetures(tdigit);
				String fvstr = "";
				for(int di = 0; di < FeatureComputer.FDIM; di++){
					fvstr = fvstr + fvec[di] + " ";
				}
				mwriter.write(fvstr + "\n");
				Log.v("Compute Activity", "" + (i+1) + ": " + fvstr);
			}
			
			inp.close();
			mwriter.close();
			fout.close();		
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	void callExtractFeatureFiles(boolean doall)
	{
		DOALL = doall;
        Thread t = new Thread()
        {
        	boolean flagall = DOALL;
            @Override
            public void run() {
                try {
                    
                	String foldername = Environment.getExternalStorageDirectory()+MainActivity.MONICOG_FOLDER;
                	File f = new File(foldername);
                	if(f.exists() == false){
                		Log.v("Admin Activity", "Creating MiniCog folder for saving files");
                		f.mkdir();
                	}
                	else {
                		Log.v("Admin Activity", "MiniCog Folder Exists");
                	}
                	
	        		File[] flist = f.listFiles(new FilenameFilter() {
	        		    public boolean accept(File f, String name) {
	        		        return name.toLowerCase().endsWith(".mc");
	        		    }
	        		});
                	
                	int len = flist.length;
                	
                	for(int k = 0; k < len; k++){
                    	
                		String ofname = foldername + "/" + flist[k].getName() + ".txt";
                		File foo = new File(ofname);
                		
                    	if(flagall == false){
                    		if(foo.exists())
                    			continue;
                    	}
                    	                     	
                    	callExtractFeatureFilesInner(flist[k], foo);
                    	
            			TEMP_MSG =  "Done Features for: " + flist[k].getName();
            			Log.v("ComputeAct", TEMP_MSG);
            			//updateStatus();	
                	}
                	
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        t.start();
	}
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_compute);
		tvstatus = (TextView) this.findViewById(R.id.textViewStatusAdmin);
		tvstatus.setMovementMethod(new ScrollingMovementMethod());
		handler = new Handler();
		fcom = new FeatureComputer();
	}
	
	
	public void onFeatureClicked(View v){
	    if(v.getId() == R.id.buttonAllFeature){
	        Log.v("Compute Activity", "All files button clicked.");
	        this.callExtractFeatureFiles(true);
	    }
	    else if(v.getId() == R.id.buttonNewFeature) {
	    	Log.v("Compute Activity", "New files button clicked.");
	    	this.callExtractFeatureFiles(false);
	    }
	}
	
	public void onTestClicked(View v){
	    if(v.getId() == R.id.buttonCorssValidation){
	        Log.v("Compute Activity", "Cross validation button clicked.");
	        callCrossValidation();

	    }
	    else if(v.getId() == R.id.buttonTestLast) {
	    	Log.v("Compute Activity", "Test last only button clicked.");
	    	this.callTestOnlyLastFile();
	    }
	}
	
	public void onPageAdminDoneClicked(View v){
	    if(v.getId() == R.id.buttonNextPageAdmin){
	        Log.v("Compute Activity", "Next button clicked.");
	        Intent intent = new Intent(this, MainActivity.class);
	        startActivity(intent);
	    }
	}
	
}
