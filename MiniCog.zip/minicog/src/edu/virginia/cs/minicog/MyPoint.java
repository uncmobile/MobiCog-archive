package edu.virginia.cs.minicog;

public class MyPoint implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -753277371763671562L;
	public float X;
	public float Y;
	public MyPoint() {
		X = 0;
		Y = 0;
	}
	public MyPoint(float x, float y) {
		X = x;
		Y = y;
	}
	
	public float dsqr(MyPoint pn) {
		float dx = X - pn.X;
		float dy = Y - pn.Y;
		return dx*dx + dy*dy;
	}
}
