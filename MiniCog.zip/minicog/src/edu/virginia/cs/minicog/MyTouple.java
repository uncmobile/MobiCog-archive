package edu.virginia.cs.minicog;

public class MyTouple {

	float val;
	int id;
	
	public MyTouple(int id1, float val1) {
		id = id1;
		val = val1;
	}
}


